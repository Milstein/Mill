import Morris

-- | 'main' runs the main program
main :: IO ()
main = do 
		play newGame
		putStrLn "Done"

mainP2 :: IO()
mainP2 =  do 
		play p2Game
		putStrLn "Done"
