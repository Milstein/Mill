Morris
======

Nine Men's Morris Game


Ideas for the AI
	Minimax algorithm with alpha beta pruning
		Using lazyness of Haskell
		Reusing already computed tree
		limit of time
	Evaluation function
		Mills possible (++)
		Stuck stones (--)
		E = Mills possible for me - for opponent ? number of stones for me - number of opponent stones? 
		Numbers of ply to evaluate ? Depending of a level of difficulty

	Should we eliminate symmetric states ?  