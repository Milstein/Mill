module Templates where

import Data.Sequence (Seq, fromList)
import Data.Maybe


