Nine-Men-Morris-Board-Strategy-Game--Java-
==========================================

Nine Men's Morris is a strategy board game for two players. Each player has 9 pieces which can be placed on intersections of lines (23 in number). The goal is to capture opponents pieces by getting three pieces on a single line (a mill). 