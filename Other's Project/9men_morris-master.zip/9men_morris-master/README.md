9men_morris
===========

A JavaScript implementation of Nie Men Morris