// Copyright (c) 2013 Cristian Patrasciuc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "game/mill_event_listener.h"

namespace game {

MillEventListener::~MillEventListener() {}

}  // namespace game
