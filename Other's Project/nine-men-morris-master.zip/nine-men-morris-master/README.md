nine-men-morris
===============

[![Build Status](https://travis-ci.org/cpatrasciuc/nine-men-morris.png?branch=master)](https://travis-ci.org/cpatrasciuc/nine-men-morris)

Nine Men's Morris game.

![screenshot](https://github.com/cpatrasciuc/nine-men-morris/blob/master/img/console_game.png?raw=true)

