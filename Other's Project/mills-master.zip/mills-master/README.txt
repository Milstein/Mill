Software Engineering Team Project: 
Nine Men's Morris. 
