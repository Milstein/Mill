Online implementation of board game Nine Men's Morris. Coded in Javascript and HTML.

This project was part of a much larger initiative to port board games to online and mobile platforms.

The holder of these projects is a research organization in UC Berkeley called GamesCrafters.

To run the game, just run the meta.html file in your favorite browser!

Main file: gameSpecificMeta.js.
