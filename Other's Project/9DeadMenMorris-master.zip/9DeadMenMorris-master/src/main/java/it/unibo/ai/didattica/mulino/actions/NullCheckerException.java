package it.unibo.ai.didattica.mulino.actions;

public class NullCheckerException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NullCheckerException() {
		super("Checker is null!");
	}
}
