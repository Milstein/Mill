package main.scala.model

/**
 * Created by tmnd on 29/05/14.
 */
object MyPhase extends Enumeration {
  type MyPhase = Value
  val Phase1, Phase2, Phase3 = Value
}

