Kurna
=====

A Nine Men's Morris game

### Enable automatic library download

[NuGet](http://nuget.org/) will need to be installed

In Visual Studio go to `Tools->Options->Package Manager`

Check "Allow NuGet to download missing packages during build"
